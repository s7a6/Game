package com.cityunderfire.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
